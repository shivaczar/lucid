package org.example;

import org.example.constant.LocationType;
import org.example.model.BestLocationAndTime;
import org.example.model.DeliveryExecutive;
import org.example.model.Location;
import org.example.service.impl.FastestDeliveryStrategy;
import org.example.service.interfaces.StartingLocationStrategy;

import java.util.List;

public class Main {
    private StartingLocationStrategy strategy;

    public Main(StartingLocationStrategy strategy) {
        this.strategy = strategy;
    }

    public BestLocationAndTime findBestStartingLocation(List<Location> locations, DeliveryExecutive deliveryExecutive) {
        return strategy.findBestStartingLocation(locations, deliveryExecutive);
    }

    // Other methods related to delivery optimization

    public static void main(String[] args) {
        // Define locations and delivery executive
//        Location C1 = new Location("Consumer 1", 12.9345, 77.6254, 0, LocationType.CONSUMER);
//        Location C2 = new Location("Consumer 2", 12.9279, 77.6271, 0, LocationType.CONSUMER);
//        Location R1 = new Location("Restaurant 1", 12.9352, 77.6185, 15, LocationType.RESTAURANT);
//        Location R2 = new Location("Restaurant 2", 12.9301, 77.6227, 10, LocationType.RESTAURANT);
        Location C1 = new Location("Consumer 1", 12.9345, 77.6254, 0, LocationType.CONSUMER);
        Location C2 = new Location("Consumer 2", 12.9245, 77.6154, 0, LocationType.CONSUMER);
        Location R1 = new Location("Restaurant 1", 12.9445, 77.6354, 15, LocationType.RESTAURANT);
        Location R2 = new Location("Restaurant 2", 12.9195, 77.6204, 10, LocationType.RESTAURANT);


        DeliveryExecutive aman = new DeliveryExecutive("Aman", 20); // Speed in km/hr

        List<Location> locations = List.of(C1, C2, R1, R2);

        // Create DeliveryOptimizer instance with desired strategy
        Main optimizer = new Main(new FastestDeliveryStrategy());

        // Calculate shortest delivery time
        BestLocationAndTime bestLocation = optimizer.findBestStartingLocation(locations, aman);
        double minDeliveryTime = 0;

        System.out.println("Best location to start: " + bestLocation.getBestLocation().getName());
        System.out.println("Minimum delivery time: " + bestLocation.getMinTime() + " hours");
}
}