package org.example.constant;

public enum LocationType {
    RESTAURANT,
    CONSUMER
}