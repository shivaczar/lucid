package org.example.model;

public class BestLocationAndTime {
    private Location bestLocation;
    private double minTime;

    public BestLocationAndTime(Location bestLocation, double minTime) {
        this.bestLocation = bestLocation;
        this.minTime = minTime;
    }

    public Location getBestLocation() {
        return bestLocation;
    }

    public double getMinTime() {
        return minTime;
    }
}
