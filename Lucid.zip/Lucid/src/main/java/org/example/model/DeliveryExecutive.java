package org.example.model;

public class DeliveryExecutive {
    private String name;
    private double speed; // Speed in km/hr

    public DeliveryExecutive(String name, double speed) {
        this.name = name;
        this.speed = speed;
    }

    public String getName() {
        return name;
    }

    public double getSpeed() {
        return speed;
    }
}
