package org.example.model;

import org.example.constant.LocationType;

public class Location {
    private String name;
    private double latitude;
    private double longitude;
    private int prepTime; // Preparation time in minutes
    private LocationType type; // Type of location: Restaurant or Consumer

    public Location(String name, double latitude, double longitude, int prepTime, LocationType type) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.prepTime = prepTime;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getPrepTime() {
        return prepTime;
    }

    public LocationType getType() {
        return type;
    }
}
