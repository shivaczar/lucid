package org.example.service.impl;

import org.example.model.BestLocationAndTime;
import org.example.model.DeliveryExecutive;
import org.example.model.Location;
import org.example.service.interfaces.StartingLocationStrategy;
import org.example.util.LocationUtils;

import java.util.List;


public class FastestDeliveryStrategy implements StartingLocationStrategy {
    @Override
    public BestLocationAndTime findBestStartingLocation(List<Location> locations, DeliveryExecutive deliveryExecutive) {
        double[][] travelTimes = new double[locations.size()][locations.size()];

        // Precalculate travel times from each location to every other location
        for (int i = 0; i < locations.size(); i++) {
            for (int j = 0; j < locations.size(); j++) {
                if (i != j) {
                    travelTimes[i][j] = LocationUtils.calculateTravelTime(locations.get(i), locations.get(j), deliveryExecutive.getSpeed());
//                    System.out.println("Travel time from " + locations.get(i).getName() + " to " + locations.get(j).getName() + ": " + travelTimes[i][j]);
                }
            }
        }

        Location bestLocation = null;
        double minTime = Double.MAX_VALUE;

        // Calculate total delivery time for each starting location
        for (int i = 0; i < locations.size(); i++) {
            double totalTime = 0;

            for (int j = 0; j < locations.size(); j++) {
                if (i != j) {
                    // Add travel time to destination
                    totalTime += travelTimes[i][j];
                    // Add preparation time at destination
                    totalTime += locations.get(j).getPrepTime();
                }
            }

//            System.out.println("Total delivery time for starting location " + locations.get(i).getName() + ": " + totalTime);

            if (totalTime < minTime) {
                minTime = totalTime;
                bestLocation = locations.get(i);
            }
        }

        // Round minTime to 4 decimal places
        minTime = Math.round(minTime * 10000.0) / 10000.0;

//        System.out.println("Best location to start: " + bestLocation.getName());
//        System.out.println("Minimum delivery time: " + minTime + " hours");

        return new BestLocationAndTime(bestLocation, minTime);
    }

}
