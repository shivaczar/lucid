package org.example.service.interfaces;

import org.example.model.BestLocationAndTime;
import org.example.model.DeliveryExecutive;
import org.example.model.Location;

import java.util.List;

public interface StartingLocationStrategy {
    BestLocationAndTime findBestStartingLocation(List<Location> locations, DeliveryExecutive deliveryExecutive);
}
